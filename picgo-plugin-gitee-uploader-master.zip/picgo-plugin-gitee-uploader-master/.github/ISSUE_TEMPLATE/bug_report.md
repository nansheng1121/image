---
name: Bug report
about: Create a report to help us improve
title: "[BUG]主要的BUG描述标题"
labels: bug
assignees: ''

---

**描述bug**
系统和软件等环境的版本
具体的bug信息.

**步骤**
具体步骤

**截图**
如果有截图的话

**Additional context**
Add any other context about the problem here.
