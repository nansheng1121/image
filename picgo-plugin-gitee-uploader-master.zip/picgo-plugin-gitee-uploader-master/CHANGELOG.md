## [1.1.2](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/compare/1.1.0...1.1.2) (2019-06-23)


### Bug Fixes

* 修复上传删除包含中英文失败的问题 ([052708b](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/commit/052708b)), closes [#2](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/issues/2)



# [1.1.0](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/compare/1.0.4...1.1.0) (2019-06-20)


### Features

* 支持自动配置path ([1609c20](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/commit/1609c20))



## [1.0.4](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/compare/1.0.2...1.0.4) (2019-06-19)



## [1.0.2](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/compare/1.0.1...1.0.2) (2019-06-19)


### Bug Fixes

* 修复customUrl不生效的bug ([b57544d](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/commit/b57544d)), closes [#1](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/issues/1)



## [1.0.1](https://github.com/lizhuangs/picgo-plugin-gitee-uploader/compare/1.0.0...1.0.1) (2019-06-18)



# 1.0.0 (2019-06-09)



